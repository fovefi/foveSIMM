/* In order to run the scala code, the following main method can be
 * added to the file foveSIMM_without_wrapper.scala (before the final
 * closing "}".
 *
 * The file can be saved in a file called foveSIMM.scala.
 * This file can then be compiled by:
 *
 * scalac foveSIMM.scala
 *
 * and then run by:
 *
 * scala foveSIMM
 */

def main(args: Array[String]) {

  println("IR risk: " + asset_risk(ir_string));
  println("CR risk: " + asset_risk(cr_string));
  println("EQ risk: " + asset_risk(eq_string));
  println("CO risk: " + asset_risk(co_string));
  

// END OF main
}
